﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnPlayUI : MonoBehaviour
{
    [SerializeField] Canvas myCanvas;

}
