﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemPool : Singleton<ItemPool>
{
    [SerializeField] GameObject[] allItems;
    [HideInInspector] public List<GameObject> recievedItems = new List<GameObject>();
    [HideInInspector] public List<GameObject> notRecievedItems = new List<GameObject>();
    [HideInInspector] public List<GameObject> instantiatedItems = new List<GameObject>();
    [HideInInspector] public List<GameObject> notInstantiatedItems;

    protected override void Awake()
    {
        base.Awake();
        notInstantiatedItems = new List<GameObject>();
        foreach (GameObject go in allItems)
        {
            if (go.GetComponent<ItemPickUp>().itemDefinition.isResieved) recievedItems.Add(go);
            else notRecievedItems.Add(go);
            notInstantiatedItems.Add(go);
        }
    }

    public GameObject GetItemToInstantiate()
    {
        GameObject result = notInstantiatedItems[Random.Range(0, notInstantiatedItems.Count)];
        instantiatedItems.Add(result);
        notInstantiatedItems.Remove(result);
        return result;
    }

}
