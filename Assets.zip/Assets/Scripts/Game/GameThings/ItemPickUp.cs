﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemPickUp : MonoBehaviour
{
    public Item_SO itemDefinition;

    [SerializeField] public ICollectableItem itemScript;
    private void Start()
    {
        itemScript = gameObject.GetComponent<ICollectableItem>();
    }
    public void StoreItemInInventory()
    {
        itemScript.ItemPickUpped();
        CharacterInventory.Instance.StoreItem(this);
    }
    
}
