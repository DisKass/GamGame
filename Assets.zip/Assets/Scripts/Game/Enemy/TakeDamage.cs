﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(CharacterStats))]
public class TakeDamage : MonoBehaviour
{
    [SerializeField] bool IsPlayer = false;

    CharacterStats _characterStats;

    public Events.EventDamageRecieved OnDamageRecieved = new Events.EventDamageRecieved();

    float knockValue = 1;
    private void Start()
    {
        OnDamageRecieved.AddListener(Pop_Ups.Instance.HandleOnDamageRecieved);

        _characterStats = GetComponent<CharacterStats>();


    }
    public void Damage(Bullet.DamageInfo damageInfo)
    {
        _characterStats.health -= damageInfo.Damage;
        if (_characterStats.health <= 0)
        {
            if (IsPlayer)
            {
                if (GameManager.Instance.CurrentGameState == GameManager.GameState.RUNNING)
                    GameManager.Instance.RestartGame();
            }
            else
            {
                gameObject.SetActive(false);
            }
        }
        OnDamageRecieved.Invoke(damageInfo, transform);
    }
    public void DotDamage(Bullet.DamageInfo damageInfo)
    {
        (float time, Bullet.DamageInfo damageInfo) damage;
        damage.time = 1;
        damage.damageInfo = damageInfo;
        StartCoroutine("takeDotDamage", damage);
    }

    IEnumerator takeDotDamage((float time, Bullet.DamageInfo damageInfo) info)
    {
        float step = info.time / 10;
        float startTime = Time.deltaTime;
        while (startTime + info.time > Time.deltaTime)
        {
            Damage(info.damageInfo);
            yield return new WaitForSeconds(step);
        }
    }

    //private void OnTriggerEnter2D(Collider2D other)
    //{
    //    if (other.TryGetComponent(out Bullet b))
    //    {
    //        Damage(b._damageInfo);
    //    }
    //}
}
