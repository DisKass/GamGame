﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class EnemyHealthbar : MonoBehaviour
{
    [SerializeField] SpriteRenderer frontLine;
    [SerializeField] TextMeshPro healthText;
    [SerializeField] TakeDamage target;
    CharacterStats enemyStats;
    float multiplier;

    void Start()
    {
        target.OnDamageRecieved.AddListener(DamageRecievedHandler);
        enemyStats = target.gameObject.GetComponent<CharacterStats>();
        multiplier = 1 / enemyStats.maxHealth;
        healthText.text = enemyStats.health + "/" + enemyStats.maxHealth;
    }
    void DamageRecievedHandler(Bullet.DamageInfo damageInfo, Transform target)
    {
        if (enemyStats.health > 0)
        {
            frontLine.transform.localScale = new Vector3(enemyStats.health * multiplier, 1, 1);
            healthText.text = enemyStats.health + "/" + enemyStats.maxHealth;
        }
        else
        {
            frontLine.transform.localScale = new Vector3(0, 1, 1);
            healthText.text = 0 + "/" + enemyStats.maxHealth;
        }

    }
}
