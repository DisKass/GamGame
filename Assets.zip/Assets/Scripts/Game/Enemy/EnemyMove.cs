﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[RequireComponent(typeof(Rigidbody2D))]
public class EnemyMove : MonoBehaviour
{
    [SerializeField] MoveType _moveType = MoveType.RandomMoving;
    [SerializeField] float _minIdleTime = 1f;
    [SerializeField] float _maxIdleTime = 3f;
    [SerializeField] float _minMovingTime = 1f;
    [SerializeField] float _maxMovingTime = 3f;
    CharacterStats enemyStats;

    Animator enemyAnimator;

    float _idleTime;
    float _movingTime;
    bool _isIdle;

    Rigidbody2D _rigidbody;
    Vector2 _moveDirection;
    SpriteRenderer spriteRenderer;

    void Start()
    {
        _rigidbody = GetComponent<Rigidbody2D>();
        enemyStats = GetComponent<Enemy>().enemyStats;
        enemyAnimator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        switch (_moveType)
        {
            case MoveType.RandomMoving:
                _rigidbody.drag = enemyStats.drag;
                break;
            case MoveType.RandomImpulseMoving:
                _rigidbody.drag = enemyStats.drag;
                break;
            default:
                break;
        }
    }

    void Update()
    {
        switch (_moveType)
        {
            case MoveType.RandomMoving:
                RandomMoving();
                break;
            case MoveType.RandomImpulseMoving:
                RandomImpulseMoving();
                break;
            default:
                break;
        }
    }
    void RandomMoving()
    {
        if (_isIdle)
        {
            if (_idleTime > Time.time) return;
            else // Переход в статус ходьбы
            {
                _isIdle = false;
                _moveDirection = Random.insideUnitCircle;
                _movingTime = Time.time + Random.Range(_minMovingTime, _maxMovingTime);
                enemyAnimator.SetBool("Move", true);
            }
        }
        if (_movingTime > Time.time)
        {
            _rigidbody.AddForce(_moveDirection * enemyStats.speed * Time.deltaTime * 100);
            spriteRenderer.flipX = Mathf.Sign(_moveDirection.x) > 0 ? false : true;
        }
        else
        {
            _isIdle = true;
            _idleTime = Time.time + Random.Range(_minIdleTime, _maxIdleTime);
            enemyAnimator.SetBool("Move", false);
        }
    }
    void RandomImpulseMoving()
    {

    }

    enum MoveType
    {
        RandomMoving,
        RandomImpulseMoving
    }
}
