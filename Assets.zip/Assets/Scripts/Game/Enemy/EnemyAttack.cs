﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

enum AttackType
{
    FIRE
}
public class EnemyAttack : MonoBehaviour
{
    [SerializeField] AttackType attackType;
    [SerializeField] CharacterStats enemyStats;
    [SerializeField] GameObject firePosition;
    GameObject player;

    [SerializeField] Bullet.DamageType damageType;
    Bullet.BulletInfo bulletInfo;
    Bullet.DamageInfo damageInfo;

    float lastShot = 0;
    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player");

        damageInfo.UpdateInfo(Damage: enemyStats.damage, damageType: damageType);
        bulletInfo.UpdateInfo(sourceTag: tag, Damage: damageInfo, Speed: enemyStats.bulletSpeed,
            LifeTime: enemyStats.bulletLifeTime, CritChance: enemyStats.critChance,
            CritMultiplier: enemyStats.critMultiplier, penetration: false);

    }
    void Update()
    {
        if (lastShot + enemyStats.reload < Time.time)
        {
            lastShot = Time.time;
            RaycastHit2D hit = Physics2D.Raycast(firePosition.transform.position, player.transform.position - firePosition.transform.position, enemyStats.attackRange, LayerMask.GetMask("Player"));
            if (hit.collider == null) return;
            bulletInfo.StartPosition = firePosition.transform.position;
            bulletInfo.Direction = Vector2.ClampMagnitude(hit.point - (Vector2)firePosition.transform.position, 1);
            FireManager.Instance.Fire(bulletInfo);
        }
    }
}
