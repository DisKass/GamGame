﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(EnemyMove))]
[RequireComponent(typeof(EnemyAttack))]
[RequireComponent(typeof(SpriteRenderer))]
[RequireComponent(typeof(Animator))]
public class Enemy : MonoBehaviour
{
    [SerializeField] public CharacterStats enemyStats;

    private void Start()
    {
        GetComponent<Animator>().runtimeAnimatorController = enemyStats.playerAnimatorController;
    }
}
