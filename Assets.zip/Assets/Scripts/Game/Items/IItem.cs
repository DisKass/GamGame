﻿public interface IItem
{
    //UnityEngine.GameObject myGameObject { get; set; }
    
}

//public interface ICollectableItem : IItem
//{
//    void StoreItemInInventory();
//}
