﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class PlayerHealthBar : MonoBehaviour
{
    [SerializeField] Image frontLine;
    [SerializeField] Text healthText;
    CharacterStats _playerStats;
    float multiplier;

    private void OnEnable()
    {
        _playerStats = GameObject.FindGameObjectWithTag("Player").GetComponent<CharacterStats>();
        _playerStats.gameObject.GetComponent<TakeDamage>().OnDamageRecieved.AddListener(DamageRecievedHandler);
        multiplier = 1 / _playerStats.maxHealth;
        frontLine.transform.localScale = new Vector3(_playerStats.health * multiplier, 1, 1);
        healthText.text = _playerStats.health + "/" + _playerStats.maxHealth;
    }
    void DamageRecievedHandler(Bullet.DamageInfo damageInfo, Transform target)
    {
        if (_playerStats.health > 0)
        {
            frontLine.transform.localScale = new Vector3(_playerStats.health * multiplier, 1, 1);
            healthText.text = _playerStats.health + "/" + _playerStats.maxHealth;
        }
        else
        {
            frontLine.transform.localScale = new Vector3(0, 1, 1);
            healthText.text = 0 + "/" + _playerStats.maxHealth;
        }

    }
}
