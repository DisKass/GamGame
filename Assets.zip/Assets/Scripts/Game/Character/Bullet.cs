﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    [System.Serializable]
    public struct DamageType
    {
        public bool IsCritical;
        public bool IsFire;
        public bool IsDot;
        public void UpdateInfo(bool IsCritical = false, bool IsFire = false, bool IsDot = false)
        {
            this.IsCritical = IsCritical;
            this.IsFire = IsFire;
            this.IsDot = IsDot;
        }
        public void UpdateInfo(DamageType info)
        {
            IsCritical = info.IsCritical;
            IsFire = info.IsFire;
            IsDot = info.IsDot;
        }
    }
    public struct DamageInfo
    {
        public float Damage;
        public DamageType damageType;
        public void UpdateInfo(float Damage = 0, DamageType damageType = default)
        {
            this.Damage = Damage;
            this.damageType = damageType;
        }
    }
    public struct BulletInfo
    {
        public DamageInfo DamageInfo;
        public string sourceTag { get; set; }
        public float Speed { get; set; }
        public float CritChance { get; set; }
        public float CritMultiplier { get; set; }
        public Vector2 Direction { get; set; }
        public Vector2 StartPosition { get; set; }
        public float LifeTime { get; set; }

        public bool penetration;
        public void UpdateInfo(string sourceTag = default, DamageInfo Damage = default, float Speed = 0,
            Vector2 Direction = default, Vector2 StartPosition = default, float LifeTime = 0,
            float CritChance = 0, float CritMultiplier = 0, bool penetration = false)
        {
            this.sourceTag = sourceTag;
            this.DamageInfo = Damage;
            this.Speed = Speed;
            this.Direction = Direction;
            this.StartPosition = StartPosition;
            this.LifeTime = LifeTime;
            this.CritChance = CritChance;
            this.CritMultiplier = CritMultiplier;
            this.penetration = penetration;
        }
    }


    public BulletInfo _bulletInfo;
    public Sprite Sprite { get; set; }

    public Events.EventDamageDone OnDamageDone = new Events.EventDamageDone();

    public Bullet Initialize(BulletInfo bulletInfo, Sprite sprite)
    {
        gameObject.AddComponent<SpriteRenderer>().sprite = sprite;
        gameObject.AddComponent<BoxCollider2D>().isTrigger = true;
        UpdateValues(bulletInfo);
        return this;
    }
    public Bullet UpdateValues(BulletInfo bulletInfo)
    {
        _bulletInfo = bulletInfo;
        return this;
    }

    public Bullet Fire()
    {
        transform.position = _bulletInfo.StartPosition;
        StartCoroutine("moving");
        return this;
    }
    IEnumerator moving()
    {
        float startTime = Time.time;
        while (Time.time - startTime < _bulletInfo.LifeTime)
        {
            transform.position += (Vector3)_bulletInfo.Direction * _bulletInfo.Speed * Time.deltaTime;
            yield return new WaitForEndOfFrame();
        }
        gameObject.SetActive(false);
    }

    //void UpdateDamageInfo()
    //{
    //    _damageInfo.Damage = _bulletInfo.Damage;

    //    _damageInfo.isCritical = Random.value < _bulletInfo.CritChance;
    //    if (_damageInfo.isCritical)
    //        _damageInfo.Damage = _bulletInfo.Damage * _bulletInfo.CritMultiplier;
    //}

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == _bulletInfo.sourceTag)
            return;
        if (!other.isTrigger)
        {
            if (other.tag == "Player" || other.tag == "Enemy")
                return;
        }
        if (other.TryGetComponent(out TakeDamage td))
        {
            if (other.isTrigger == true)
            {
                //UpdateDamageInfo();
                td.Damage(_bulletInfo.DamageInfo);
                OnDamageDone.Invoke(_bulletInfo, td.gameObject);
                //td.DotDamage(_damageInfo);
            }
        }
        if (!_bulletInfo.penetration)
        {
            OnDamageDone.RemoveAllListeners();
            gameObject.SetActive(false);
        }
    }
}
