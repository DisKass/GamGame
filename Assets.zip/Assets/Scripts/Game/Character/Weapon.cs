﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
public class Weapon : MonoBehaviour
{
    public float reloadMultiplier = 1f;
    public Bullet.DamageType damageType;

    public List<GameObject> _bulletSpawnPoints;

    private void Start()
    {
        for(int i = 0; i < transform.childCount; i++)
        {
            _bulletSpawnPoints.Add(transform.GetChild(i).gameObject);
        }
    }

    public void AddGunpoint(Vector2 bulletSpawnPoint, Vector2 direction)
    {
        GameObject gameObject = new GameObject();
        gameObject.transform.position = bulletSpawnPoint;
        gameObject.transform.right = direction;
        _bulletSpawnPoints.Add(gameObject);
    }
    public void Equipped(CharacterStats playerStats)
    {
        playerStats.reload *= reloadMultiplier;
    }
    public void Unequipped(CharacterStats playerStats)
    {
        playerStats.reload /= reloadMultiplier;
    }
}
