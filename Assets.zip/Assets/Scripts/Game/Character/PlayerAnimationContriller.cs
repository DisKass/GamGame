﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerAnimationContriller : MonoBehaviour
{
    [SerializeField] Animator _playerAnimator;
    public void Move(InputAction.CallbackContext ctx)
    {
        if (ctx.ReadValue<Vector2>() != Vector2.zero)
        {
            _playerAnimator.SetBool("Move", true);
        }
        else _playerAnimator.SetBool("Move", false);
    }

}
