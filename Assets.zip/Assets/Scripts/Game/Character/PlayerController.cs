﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(CharacterStats))]

public class PlayerController : MonoBehaviour
{
    CharacterStats playerStats;
    [SerializeField] SpriteRenderer _playerSpriteRenderer;
    bool isFire = false;

    private Vector2 _movement = Vector2.zero;
    private Rigidbody2D _rigidbody;
    private Transform _transform;
    private int screenWidth;

    private int _currentYPos;
    private void Start()
    {
        playerStats = GetComponent<CharacterStats>(); ;
        screenWidth = Screen.width;
        _rigidbody = GetComponent<Rigidbody2D>();
        transform.position = playerStats.position;
        _transform = transform;
        _rigidbody.drag = playerStats.drag;
        //StartCoroutine("LateStart");
    }
    private void Update()
    {
        Fire();
        if (_currentYPos != Mathf.RoundToInt(_transform.position.y*10)) {
            _currentYPos = Mathf.RoundToInt(_transform.position.y*10);
            _playerSpriteRenderer.sortingOrder = -_currentYPos;
            WeaponManager.Instance.sortingOrder = -_currentYPos - (int)_transform.localScale.x;
        }
        
        if (_movement == Vector2.zero)
            return;
        _rigidbody.AddForce(_movement, ForceMode2D.Force);
        
    }
    public void Move(InputAction.CallbackContext ctx)
    {
        _movement = ctx.ReadValue<Vector2>().normalized*playerStats.speed;
        _rigidbody.drag = playerStats.drag;
    }
    public void Fire()
    {
        if (isFire)
            WeaponManager.Instance.Fire(tag);
    }
    public void Look(InputAction.CallbackContext ctx)
    {
        Vector2 values = ctx.ReadValue<Vector2>();
        if (values == Vector2.zero)
        {
            isFire = false;
            return;
        }
        isFire = true;
        //Debug.Log(values.x + " " + values.y);
        if (values.x <= 1 && values.x >= -1)
        {
            //values = new Vector2(Mathf.Sign(values.x), Mathf.Sign(values.y));
            GamepadLook(values);
        }
        else
            GamepadLook(values-(Vector2)(Camera.main.WorldToScreenPoint(_transform.position)));
        Fire();
        
    }
    private void GamepadLook(Vector2 value)
    {
        sbyte signX = (sbyte)Mathf.Sign(value.x);
        if (value.x != 0)
        {
            //ShowInformation.Instance.AddMessage(signX.ToString() + " " + Mathf.Sign(value.x));
            _transform.localScale = new Vector3(signX, 1, 1);
            WeaponManager.Instance.sortingOrder = _playerSpriteRenderer.sortingOrder - (int)_transform.localScale.x;
            WeaponManager.Instance.SetRotation(Quaternion.Euler(0, 0, signX*Mathf.Asin(value.y / value.magnitude)*180/Mathf.PI), signX);
        }

    }
    private void MouseLook(Vector2 value)
    {
        //if (xCoord > screenWidth / 2)
        //{
        //    _transform.localScale = new Vector3(1, 1, 1);
        //    WeaponManager.Instance.sortingOrder = _playerSpriteRenderer.sortingOrder - 1;
        //}
        //if (xCoord < screenWidth / 2)
        //{
        //    _transform.localScale = new Vector3(-1, 1, 1);
        //    WeaponManager.Instance.sortingOrder = _playerSpriteRenderer.sortingOrder + 1;
        //}
    }

    IEnumerator LateStart()
    {
        yield return new WaitForSecondsRealtime(1);
        GamepadLook(new Vector2(-1, 0));
        WeaponManager.Instance.SelectWeapon(1);
    }
}
