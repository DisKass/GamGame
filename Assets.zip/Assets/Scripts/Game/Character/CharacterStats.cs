﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterStats : MonoBehaviour
{
    [SerializeField] public CharacterStats_SO _characterStats;
    #region Fields

    [HideInInspector] public int level = 2;
    [HideInInspector] public float maxHealth;
    [HideInInspector] public float health;
    [HideInInspector] public float damage;
    [HideInInspector] public float critChance;
    [HideInInspector] public float critMultiplier = 2f;
    [HideInInspector] public float speed = 6f;
    [HideInInspector] public float drag = 5f;
    [HideInInspector] public float reload = 1f;
    [HideInInspector] public float bulletSpeed = 20f;
    [HideInInspector] public float bulletLifeTime = 1f;

    [HideInInspector] public int currentWeapon = 0;
    [HideInInspector] public float attackRange = 20f;

    [HideInInspector] public Sprite sprite;
    [HideInInspector] public RuntimeAnimatorController playerAnimatorController;

    [HideInInspector] public Vector2 position = Vector2.zero;

    private void Awake()
    {
        level = _characterStats.level;
        maxHealth = _characterStats.maxHealth;
        health = _characterStats.maxHealth;
        damage = _characterStats.damage;
        critChance = _characterStats.critChance;
        critMultiplier = _characterStats.critMultiplier;
        speed = _characterStats.speed;
        drag = _characterStats.drag;
        reload = _characterStats.reload;
        bulletSpeed = _characterStats.bulletSpeed;
        bulletLifeTime = _characterStats.bulletLifeTime;
        currentWeapon = _characterStats.currentWeapon;
        attackRange = _characterStats.attackRange;
        sprite = _characterStats.sprite;
        playerAnimatorController = _characterStats._playerAnimatorController;
        //Debug.Log("[CharacterStats] Level: " + level);
    }
    #endregion
}
